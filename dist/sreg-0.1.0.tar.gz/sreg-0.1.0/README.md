# sreg.py
This repo contains a python port for a package sreg: Stratified Randomized Experiments
